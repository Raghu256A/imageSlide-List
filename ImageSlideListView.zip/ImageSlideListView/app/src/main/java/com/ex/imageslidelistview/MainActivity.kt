package com.ex.imageslidelistview

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var dotsLayout: LinearLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var et_search: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var fabutton: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val imageResIds = listOf(
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4
        )
        val imageItemsList = listOf(
            ItemsDo(R.drawable.apple, "Apple", "Apple is Red"),
            ItemsDo(R.drawable.banana, "Banana", "Banana is Yellow"),
            ItemsDo(R.drawable.cherry, "Cherry", "Cherry is Red"),
            ItemsDo(R.drawable.guava, "Guava", "Guava is Green"),
            ItemsDo(R.drawable.mango, "Mango", "Mango is Yellow"),
            ItemsDo(R.drawable.orange, "Orange", "Orange is Orange"),
            ItemsDo(R.drawable.pineapple, "PineApple", "PineApple is Yellow & green"),
            ItemsDo(R.drawable.pomegranate, "Pomegranate", "Pomegranate is Red"),
            ItemsDo(R.drawable.strawberry, "Strawberry", "Strawberry is Red"),
            ItemsDo(R.drawable.watermelon, "Watermelon", "watermelon is Green & black")
        )

        viewPager = findViewById(R.id.viewPager)
        dotsLayout = findViewById(R.id.dotsLayout)
        et_search = findViewById(R.id.et_search)
        recyclerView = findViewById(R.id.recyclerView)
        fabutton = findViewById(R.id.fabutton)

        val adapter = ImageSliderAdapter(imageResIds)
        viewPager.adapter = adapter
        setupDots(imageResIds.size)
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
            }
        })

        recyclerView.setLayoutManager(
            LinearLayoutManager(
                this,
                LinearLayoutManager.VERTICAL,
                false
            )
        )
        val adapter1 = ItemsListViewAdapter(imageItemsList)
        recyclerView.setAdapter(adapter1)
        et_search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                adapter1.filter(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        fabutton.setOnClickListener {
            val listSize = adapter1.itemCount
            Toast.makeText(this, "Items List size: $listSize", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupDots(count: Int) {
        dotsLayout.removeAllViews()
        val dots = Array(count) { ImageView(this) }
        val layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(8, 0, 8, 0)
        }

        for (i in dots.indices) {
            dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.dot_inactive))
            dots[i].layoutParams = layoutParams
            dotsLayout.addView(dots[i])
        }
        // Highlight the first dot
        if (dots.isNotEmpty()) {
            dots[0].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.dot_active))
        }
    }
    private fun updateDots(position: Int) {
        for (i in 0 until dotsLayout.childCount) {
            val dot = dotsLayout.getChildAt(i) as ImageView
            dot.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    if (i == position) R.drawable.dot_active else R.drawable.dot_inactive
                )
            )
        }
    }

}