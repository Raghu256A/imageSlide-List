package com.ex.imageslidelistview

data class ItemsDo(
val imageResId: Int,
val title: String,
val sub_title: String
)
