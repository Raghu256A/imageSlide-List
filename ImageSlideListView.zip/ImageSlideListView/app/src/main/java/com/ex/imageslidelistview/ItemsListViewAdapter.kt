package com.ex.imageslidelistview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

 class ItemsListViewAdapter(private var items: List<ItemsDo>) : RecyclerView.Adapter<ItemsListViewAdapter.ViewHolder>() {
    private var originalItems: List<ItemsDo> = ArrayList(items)

    class ViewHolder(itemsView: View) : RecyclerView.ViewHolder(itemsView) {
        val image: ImageView = itemsView.findViewById(R.id.imageView)
        val title: TextView = itemsView.findViewById(R.id.tv_title)
        val sub_title: TextView = itemsView.findViewById(R.id.tv_subtitle)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.items_list_view, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.image.setImageResource(item.imageResId)
        holder.title.text = item.title
        holder.sub_title.text = item.sub_title
    }

    fun filter(query: String) {
        items = if (query.isEmpty()) {
            originalItems
        } else {
            originalItems.filter {
                it.title.toString().lowercase().contains(query.toString().lowercase())
            }
        }
        notifyDataSetChanged()
    }
}